clear all;clc;
% References:
% [1] Ren W Y, Li G H, Tu D, Jia L. Nonnegative Matrix Factorization With Regularizations[J].
% IEEE Journal on Emerging and Selected Topics in Circuits and Systems, 2014, 4(1): 153-164.
% [2] Ren W Y, Li G H, Tu D. Graph Clustering by Congruency Approximation[J]. IET, Computer Vision, 2015.
% [3] Ren W Y, Li G H. Graph based Semi-supervised Learning via label fitting[J].
% Springer, International Journal of Machine Learning and  Cybernetics.
% [4] Deng Cai, Xiaofei He, Jiawei Han, Thomas Huang. "Graph Regularized
% Non-negative Matrix Factorization for Data Representation", IEEE
% Transactions on Pattern Analysis and Machine Intelligence, , Vol. 33, No.8, pp. 1548-1560, 2011.
%% demo, select one dataset

addpath('related');
load Iris.mat
% load PIE_pose27-GNMF.mat
% load COIL20.mat
%% choose categories from the whole dateset for clustering
nClass=min(max(gnd),3);
%% 
fea=double(fea);
gnd=double(gnd);
X_start=fea';
[~,S_startn]=size(X_start);
All_nClass = length(unique(gnd));
%% sort labels by: 1,2,3,4,5,...
pre_step;
%%
for loop=1:10
    loop
    RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock)));
    %     RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
    %% select nClass categories from the total datasets
    [X,gnd,select_class]=selectclass(X_start,nClass,ccn,en,All_nClass);%
    [Xm,Xn]=size(X);n=Xn;k=nClass;m=Xm;
    fea=X';
    %% normalized
    fea=normalize_data(fea,1);%
    X=fea';
    %% vote neighbor GNMF- semi-supervised
    rand('twister',5489);
    %     [W,W0,M,remember,W5,R2,R,S,R0,L,Wdis]=Metric_getW_neighbor(fea',nClass,en,ccn,semi_per,select_class);%W5,metric learning distance matrix
    %% k-nn graph,coding by Cai Deng
    options =[];options.k =5;%KNN-�ھ�
    WG = constructW(fea,options);
    %%
    V1=ncutCAC(WG,nClass,0.01,1);%1,10 for ORL,stand Ncut
    V2=ncutCAC(WG,nClass,0.01,0);%1,10 for ORL, Ncut
    V3=ratiocutCAC(WG,nClass,0.01);% Ratio cut
    V4=ratiocutCAC(WG,nClass,0.1);% Ratio cut
    V5=minmaxcutCAC(WG,nClass,0.1,1);%stand Minmax cut
    V6=minmaxcutCAC(WG,nClass,0.1,1);%stand Minmax cut
    %% SymNMF, coding by Da Kuang
    %Refrence: Da Kuang, Chris Ding, Haesun Park,Symmetric Nonnegative Matrix Factorization for Graph Clustering,
    %The 12th SIAM International Conference on Data Mining (SDM '12), pp. 106--117.
    [V7, ~, ~] = symnmf_newton(WG,nClass);
    [V8, ~, ~] = symnmf_anls(WG,nClass);
    %% normalzied cut, coding by Cai Deng
    %Refrence:Shi J, Malik J. Normalized Cuts and Image Segmentation [J]. Pattern Analysis and Machine Intelligence, IEEE Transactions on, 2000, 22(8): 888-905.
    V9= normalizedcut(WG,nClass);%
    %% measure performance-clustering accuracy, normalized mutual information
    %Refrence:Xu W, Liu X, Gong Y. Document Clustering based on Non-negative Matrix Factorization [C]
    %Proceedings of the 26th Annual International ACM SIGIR Conference on
    %Research and Development in Informaion Retrieval. ACM, 2003: 267-273.
    [MIHat,AC]=computeMIAC(gnd,V1,nClass);NLE1_MIHat(loop)=MIHat;NLE1_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V2,nClass);NLE2_MIHat(loop)=MIHat;NLE2_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V3,nClass);NLE3_MIHat(loop)=MIHat;NLE3_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V4,nClass);NLE4_MIHat(loop)=MIHat;NLE4_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V5,nClass);NLE5_MIHat(loop)=MIHat;NLE5_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V6,nClass);NLE6_MIHat(loop)=MIHat;NLE6_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V7,nClass);NLE7_MIHat(loop)=MIHat;NLE7_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V8,nClass);NLE8_MIHat(loop)=MIHat;NLE8_AC(loop)=AC;
    [MIHat,AC]=computeMIAC(gnd,V9,nClass) ;NLE9_MIHat(loop)=MIHat;NLE9_AC(loop)=AC;
end
sparse1=[mean(mean(NLE1_AC)),mean(mean(NLE2_AC)),mean(mean(NLE3_AC)),mean(mean(NLE4_AC)),mean(mean(NLE5_AC)),mean(mean(NLE6_AC)),mean(mean(NLE7_AC)),mean(mean(NLE8_AC)),mean(mean(NLE9_AC))];
disp('             1           2           3            4          5            6        7          8          9');
disp(['AC         ',num2str(sparse1)]);
disp('       ');
sparse2=[mean(mean(NLE1_MIHat)),mean(mean(NLE2_MIHat)),mean(mean(NLE3_MIHat)),mean(mean(NLE4_MIHat)),mean(mean(NLE5_MIHat)),mean(mean(NLE6_MIHat)),mean(mean(NLE7_MIHat)),mean(mean(NLE8_MIHat)),mean(mean(NLE9_MIHat))];
disp('             1           2           3            4          5            6        7          8          9');
disp(['MI         ',num2str(sparse2)]);
