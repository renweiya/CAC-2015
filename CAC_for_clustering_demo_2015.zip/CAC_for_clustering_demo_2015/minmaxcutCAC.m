function V=minmaxcutCAC(W,nClass,nata2,nor)
%% 1.unnormalized minmaxcut_CAC
% min sum((vi'Lvi)/(vi'Wvi))
% s.t. V'DV=I, L=D-W.
%% 2.normalized minmaxcut_CAC
% min sum((vi'vi)/(vi'*D1*W*D1*vi))
% s.t. V'V=I, L=I-D1*W*D1. 
% D1=diag(((sum(W))).^(-0.5));
%%  relations
% V1: solution of normalized minmaxcut_CAC
% V2: solution of unnormalized minmaxcut_CAC
% we have
% V2=D1*V1;
%% 3.objective function
% sum((vi'vi)/(vi'*D1*W*D1*vi))+nata2*[tr(V'*V)-log(det(V'*V))]
% s.t. V>0.
%% 4.notes
% nClass   number of categories.
% W        similarity matrix
% nor=1;   normalized minmaxcut_CAC
% nor=0;   unnormalized minmaxcut_CAC
% nata2 can be selected from the finite grid [0.001,0.01,0.1,1]
%% 5.References:
% [1] Ren W Y, Li G H, Tu D, Jia L. Nonnegative Matrix Factorization With Regularizations[J]. 
% IEEE Journal on Emerging and Selected Topics in Circuits and Systems, 2014, 4(1): 153-164.
% [2] Ren W Y, Li G H, Tu D. Graph Clustering by Congruency Approximation[J]. IET, Computer Vision, 2015. 
% [3] Ren W Y, Li G H. Graph based Semi-supervised Learning via label fitting[J]. 
% Springer, International Journal of Machine Learning and  Cybernetics. 
% [4] C.Ding, X.He, H.Zha, et al. A Min-max cut Algorithm for Graph Partitioning and Data Clustering [C]
%  Proceedings of IEEE International Conference on Data Mining, 2001:107-114.
% [5] Deng Cai, Xiaofei He, Jiawei Han, Thomas Huang. "Graph Regularized
% Non-negative Matrix Factorization for Data Representation", IEEE
% Transactions on Pattern Analysis and Machine Intelligence, , Vol. 33, No.
% 8, pp. 1548-1560, 2011.  
[~,n]=size(W);
W=W.*(ones(n,n)-eye(n));
%% normalized
D1=diag(((sum(W))).^(-0.5));
L=eye(n)-D1*W*D1;
%%
D=(abs(L)+L)/2;
W=(abs(L)-L)/2;
%%
%%
k=nClass;
optionDefault.iter=1000;%1000
optionDefault.dis=true;
optionDefault.residual=1e-4;
optionDefault.tof=1e-4;
option=optionDefault;

rand('twister',5489);
%     RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock)));
V=rand(n,k);V=max(V,eps);
%%
for i=1:option.iter
    if nata2~=0
        p0=V*inv(V'*V);%fast
    else
        p0=zeros(n,k);
    end
    p12=nata2*(abs(p0)+p0)/2;
    p22=nata2*(abs(p0)-p0)/2;

    c_1=1./diag(V'*W*V);
    V_1=(ones(n,1)*c_1').*V;
    %
    c_2=diag(V'*D*V).*(c_1.^2);
    V_2=(ones(n,1)*c_2').*V;
    
    p23=nata2*V;%unnormalized
    
    p11=W*V_2;
    p21=D*V_1;
    
    %% 1
    %     temp=eps*(p21+p22+p23<eps);
    %     V=V.*((p11+p12)./(p21+p22+p23+temp));
    %% 2
    V=V.*((p11+p12)./(p21+p22+p23));%
    V=max(V,eps);
end
if nor==0
    V=D1*V;
end
